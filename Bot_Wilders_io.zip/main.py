import telebot
from telebot import types
import time
import re

bot = telebot.TeleBot("7973635013:AAHQeNxXpv_JJJxHCiL7yDh5PAJk61iqYwM")

# start
@bot.message_handler(commands=['start'])
def start(message):
    reply_markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    reply_markup.add("About Bot", "Convert")

    # Инлайн-кнопки
    inline_markup = types.InlineKeyboardMarkup()
    inline_markup.add(
        types.InlineKeyboardButton("About Bot", callback_data="about_bot_start"),
        types.InlineKeyboardButton("Convert", callback_data="convert_start")
    )

    # Анимация
    for _ in range(3):
        bot.send_chat_action(chat_id=message.chat.id, action='typing')
        time.sleep(0.1)

    bot.send_message(
        message.chat.id,
        "Hey there, *wilder*! 😼⚔️\n\n"
        "Welcome to our 🤖 *Wilders.io AFK Helper Bot* — the ultimate little helper to turn your in-game grind into real-life planning! "
        "Whether you're hoarding logs or farming apples, We’ve got your back😎\n\n"
        "Let’s crunch those numbers and make sure you're always prepared — in-game and IRL!\n\n"
        "If you have any issues with the bot feel free to ask\n"
        "(_directly tell the issue with 1 message - take a look at bot description for developer contacts_)\n\n"
        "🎉 *Enjoy*!",
        parse_mode="Markdown",
        reply_markup=inline_markup
    )

def parse_time_input(text):
    # Ищем значения времени по паттерну (например, 1h, 30m, 20s)
    pattern = r'(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?'
    match = re.fullmatch(pattern, text.strip().lower())

    if not match:
        return None

    hours = int(match.group(1)) if match.group(1) else 0
    minutes = int(match.group(2)) if match.group(2) else 0
    seconds = int(match.group(3)) if match.group(3) else 0

    return hours * 3600 + minutes * 60 + seconds

# Кнопка About Bot
@bot.message_handler(commands=['about'])
@bot.message_handler(func=lambda message: message.text == "About Bot")
def about_bot(message):
    bot.send_chat_action(chat_id=message.chat.id, action='typing')
    time.sleep(0.1)

    bot.send_message(message.chat.id,
                     "🤖 *Bot Version* - 1.0 (Release)\n\n"
                     "⏳ *Time, logs and apples* 🍎\n\n"
                     "✨ *Bot Features* ✨\n\n"
                     "*1️⃣*\n\n"
                     "🪵🍎 ➡️ ⏳\n"
                     "*Resources to Time Management*\n"
                     "_Keep track of your collected resources and see how long they will sustain you during your real life adventures._\n\n"
                     "*2️⃣*\n\n"
                     "⏳ ➡️ 🪵🍊\n"
                     "*Time to Resources Management*\n"
                     "_Calculate the exact amount of resources needed by specifying the precise duration of your survival._",
                     parse_mode="Markdown")

# кнопка Convert
@bot.message_handler(commands=['convert'])
@bot.message_handler(func=lambda message: message.text == "Convert")
def handle_convert(message):
    bot.send_chat_action(chat_id=message.chat.id, action='typing')
    time.sleep(0.1)

    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    btn_res_to_time = types.InlineKeyboardButton(
        text="1️⃣   🪵➡⏳ Convert Res. to Time",
        callback_data="res_to_time")
    btn_time_to_res = types.InlineKeyboardButton(
        text="2️⃣   ⏳➡🪵 Convert Time to Res.",
        callback_data="time_to_res")
    inline_markup.add(btn_res_to_time, btn_time_to_res)

    bot.send_photo(
        chat_id=message.chat.id,
        photo=open('convert_wilders_io.png', 'rb'),
        caption=(
            "*Convert Resources to Time*\n"
            "_This feature allows you to input the amount of resources you have and convert them into equivalent time._\n\n"
            "*Convert Time to Resources*\n"
            "_This feature allows you to input the amount of time you want to convert into equivalent resources_\n\n"
            "▎*Buttons*"
        ),
        parse_mode="Markdown",
        reply_markup=inline_markup
    )

# кнопка Res to Time
@bot.message_handler(commands=['res_to_time'])
@bot.message_handler(func=lambda message: message.text == "Res. to Time")
def res_to_time(message):
    bot.send_chat_action(chat_id=message.chat.id, action='typing')
    time.sleep(0.1)

    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    btn_wood_to_time = types.InlineKeyboardButton(
        text="1️⃣   🪵➡️⏳ Convert Wood to Time",
        callback_data="wood_to_time")
    btn_food_to_time = types.InlineKeyboardButton(
        text="2️⃣   🍎➡️⏳ Convert Food to Time",
        callback_data="food_to_time")
    inline_markup.add(btn_wood_to_time, btn_food_to_time)

    bot.send_photo(
        chat_id=message.chat.id,
        photo=open("Res_to_time_Wilders_io.png", "rb"),
        caption = (
            "*Logs*\n"
            "_Discover how long your furnace will keep burning with your current supply of wood._\n\n"
            "*Food*\n"
            "_Find out how long your food reserves will last._\n\n"
            "▎*Buttons*"
        ),
        parse_mode = "Markdown",
        reply_markup = inline_markup
    )

# Дерево на время
def process_wood_input(message):
    try:
        wood_amount = int(message.text)
        if wood_amount <= 0:
            raise ValueError

        total_seconds_w = wood_amount * 5

        minutes = (total_seconds_w % 3600) // 60
        hours = (total_seconds_w % 86400) // 3600
        days = (total_seconds_w % 2592000) // 86400

        decimal_hours = round(total_seconds_w / 3600, 1)  # Часы с остатком (1 цифра после запятой)

        response = (
            f"🪵 You have *{wood_amount}* logs.\n"
            f"🔥 That will last for:\n"
            f"⏰ *{days}* day(s),"
            f" *{hours}* h,"
            f" *{minutes}* min"
            f" (*{decimal_hours}* h)"
        )

        bot.send_message(message.chat.id, response, parse_mode="Markdown")

    except ValueError:
        bot.send_message(message.chat.id, "⚠️ Please enter a valid number (greater than 0).")
        bot.register_next_step_handler(message, process_wood_input)

# Время на ресурсы
@bot.message_handler(commands=['time_to_res'])
@bot.message_handler(func=lambda message: message.text == "Time to Res.")
def time_to_res(message):
    bot.send_chat_action(chat_id=message.chat.id, action='typing')
    time.sleep(0.1)

    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    btn_time_to_wood = types.InlineKeyboardButton(
        text="1️⃣   ⏳➡🪵 Convert Time to Wood",
        callback_data="time_to_wood")
    btn_time_to_food = types.InlineKeyboardButton(
        text="2️⃣   ⏳➡🍎 Convert Time to Food",
        callback_data="time_to_food")
    inline_markup.add(btn_time_to_wood, btn_time_to_food)

    bot.send_photo(
        chat_id=message.chat.id,
        photo=open("Res_to_time_Wilders_io.png", "rb"),
        caption=(
            "*Logs*\n"
            "_Find out how much wood you need for a certain amount of time._\n\n"
            "*Food*\n"
            "_Find out how much food you need for a certain amount of time._\n\n"
            "▎*Buttons*"
        ),
        parse_mode="Markdown",
        reply_markup=inline_markup
    )

# Время в дерево

def process_time_to_wood_input(message):
    time_in_seconds = parse_time_input(message.text)

    if time_in_seconds is None or time_in_seconds <= 0:
        bot.send_message(message.chat.id, "⚠️ Please enter a valid time like `1h`, `30m`, or `2h 15m`.")
        bot.register_next_step_handler(message, process_time_to_wood_input)
        return

    seconds_per_log = 5  # 5 секунд горения на 1 полено
    required_logs = round(time_in_seconds / seconds_per_log)

    bot.send_message(
        message.chat.id,
        f"🔥 To keep the fire burning for *{time_in_seconds // 60} minute(s)*, you’ll need *{required_logs}* 🪵 logs!",
        parse_mode="Markdown"
    )

# Время в еду
def process_time_to_specific_food(message, food_type):
    time_in_seconds = parse_time_input(message.text)

    if time_in_seconds is None or time_in_seconds <= 0:
        bot.send_message(message.chat.id, "⚠️ Please enter a valid time like `1h`, `30m`, or `2h 15m`.")
        bot.register_next_step_handler(message, lambda msg: process_time_to_specific_food(msg, food_type))
        return

    food_durations = {
        "apples": 20,
        "rawmeat": 20,
        "cookedmeat": 60,
        "salad": 134
    }

    food_names = {
        "apples": "Oranges/Apples 🍊🍎",
        "rawmeat": "Raw Meat 🥩",
        "cookedmeat": "Cooked Meat 🍖",
        "salad": "Fruit Salad 🥗"
    }

    seconds_per_unit = food_durations.get(food_type, 1)
    required_amount = round(time_in_seconds / seconds_per_unit)

    bot.send_message(
        message.chat.id,
        f"🍽 To fill your stomach for *{time_in_seconds // 60} minute(s)*, you’ll need *{required_amount}* of {food_names[food_type]}!",
        parse_mode="Markdown"
    )


#кнопки еды
def show_food_options(message, mode="amount"):
    bot.send_chat_action(chat_id=message.chat.id, action='upload_photo')
    time.sleep(0.1)

    # В зависимости от режима назначаем префиксы callback_data
    prefix = "food" if mode == "amount" else "time_food"

    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    inline_markup.add(
        types.InlineKeyboardButton("1⃣ 🍊🍎 Oranges / Apples", callback_data=f"{prefix}_apples"),
        types.InlineKeyboardButton("2⃣ 🥩 Raw Meat", callback_data=f"{prefix}_rawmeat"),
        types.InlineKeyboardButton("3⃣ 🍖 Cooked Meat", callback_data=f"{prefix}_cookedmeat"),
        types.InlineKeyboardButton("4⃣ 🥗 Fruit Salad", callback_data=f"{prefix}_salad")
    )

    bot.send_photo(
        chat_id=message.chat.id,
        photo=open("food_convert_wildersio.png", "rb"),
        caption=(
            "🍊🍎 *Oranges / Apples*\n"
            "+10% 🥩 satiety\n\n"
            "🥩 *Raw Meat*\n"
            "+5% 🥩 satiety\n\n"
            "🍖 *Cooked Meat*\n"
            "+30% satiety\n\n"
            "🥗 *Fruit Salad*\n"
            "+70% satiety\n\n"
            "▎*Buttons*"
        ),
        parse_mode="Markdown",
        reply_markup=inline_markup
    )

# Калькулятор еды
def process_food_input(message, food_type):
    try:
        count = int(message.text)
        if count <= 0:
            raise ValueError

        # Секунды на 1 единицу еды
        food_durations = {
            "apples": 20,
            "rawmeat": 20,
            "cookedmeat": 60,
            "salad": 134
        }

        total_seconds = count * food_durations.get(food_type, 0)

        minutes = (total_seconds % 3600) // 60
        hours = (total_seconds % 86400) // 3600
        days = (total_seconds % 2592000) // 86400
        decimal_hours = round(total_seconds / 3600, 1)

        food_names = {
            "apples": "Oranges/Apples 🍊🍎",
            "rawmeat": "Raw Meat 🥩",
            "cookedmeat": "Cooked Meat 🍖",
            "salad": "Fruit Salad 🥗"
        }

        response = (
            f"{food_names[food_type]}\n"
            f"📦 You have *{count}*.\n"
            f"⏳ That will last for:\n"
            f"*{days}* day(s), *{hours}* h, *{minutes}* min (*{decimal_hours}* h)"
        )

        bot.send_message(message.chat.id, response, parse_mode="Markdown")

    except ValueError:
        bot.send_message(message.chat.id, "⚠️ Please enter a valid number (greater than 0).")
        bot.register_next_step_handler(message, lambda msg: process_food_input(msg, food_type))

# Инлайн-кнопки
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    bot.answer_callback_query(call.id)

    if call.data == "res_to_time":
        res_to_time(call.message)

    elif call.data == "time_to_res":
        time_to_res(call.message)

    elif call.data == "time_to_wood":
        bot.send_message(call.message.chat.id, "🔥 All right, Wilder, now tell me for how long do you need your furnace to be burning?")
        bot.register_next_step_handler(call.message, process_time_to_wood_input)

    elif call.data == "about_bot_start":
        about_bot(call.message)

    elif call.data == "convert_start":
        handle_convert(call.message)

    elif call.data == "wood_to_time":
        bot.send_message(call.message.chat.id, "🌲 All right, Wilder, now tell me how much wood you have?")
        bot.register_next_step_handler(call.message, process_wood_input)

    elif call.data == "food_to_time":
        show_food_options(call.message)

    elif call.data.startswith("food_"):
        food_name = call.data.split("_")[1]
        food_prompts = {
            "apples": "🍊🍎 All right, Wilder, now tell me how many Oranges/Apples do you have?",
            "rawmeat": "🥩 All right, Wilder, now tell me how much Raw Meat do you have?",
            "cookedmeat": "🍖 All right, Wilder, now tell me how much Cooked Meat do you have?",
            "salad": "🥗 All right, Wilder, now tell me how many Fruit Salads do you have?",
        }

        prompt = food_prompts.get(food_name, "How many items do you have?")
        bot.send_message(call.message.chat.id, prompt)
        bot.register_next_step_handler(call.message, lambda msg: process_food_input(msg, food_name))

    elif call.data == "time_to_food":
        show_food_options(call.message, mode="time")

    elif call.data.startswith("time_food_"):
        food_name = call.data.split("_")[2]
        food_prompts = {
            "apples": "🍊🍎 All right, Wilder, now tell me for how long do you want your stomach to be filled with Apples/Oranges?",
            "rawmeat": "🥩 All right, Wilder, now tell me for how long do you want your stomach to be filled with Raw Meat?",
            "cookedmeat": "🍖 All right, Wilder, now tell me for how long do you want your stomach to be filled with Cooked Meat?",
            "salad": "🥗 All right, Wilder, now tell me for how long do you want your stomach to be filled with Fruit Salads?",
        }

        prompt = food_prompts.get(food_name, "🕐 How long do you want to stay full?")
        bot.send_message(call.message.chat.id, prompt)
        bot.register_next_step_handler(call.message, lambda msg: process_time_to_specific_food(msg, food_name))


# Меню
commands = [
    types.BotCommand("start", "▶️ Start the bot"),
    types.BotCommand("about", "ℹ️ Information about the bot"),
    types.BotCommand("convert", "🔄 Convert resources or time"),
]
bot.set_my_commands(commands)

while True:
    try:
        print("Бот запущен!")
        bot.polling(none_stop=True, timeout=60, long_polling_timeout=60)
    except Exception as e:
        print(f"Ошибка: {e}")
        time.sleep(5)

# Запуск
print("Бот запущен!")
bot.polling(none_stop=True, timeout=60, long_polling_timeout=60)
